(function(){
var btn=document.querySelector('.menu-btn'),nav=document.getElementById('nav');
if(!btn||!nav)return;
function set(o){nav.classList.toggle('open',o);btn.setAttribute('aria-expanded',o);btn.setAttribute('aria-label',o?'Менюну жабуу':'Менюну ачуу');}
btn.addEventListener('click',function(){set(!nav.classList.contains('open'));});
nav.addEventListener('click',function(e){if(e.target.tagName==='A')set(false);});
document.addEventListener('keydown',function(e){if(e.key==='Escape')set(false);});
window.addEventListener('resize',function(){if(innerWidth>900)set(false);});
if('IntersectionObserver' in window){
  var links={};nav.querySelectorAll('a').forEach(function(a){links[a.getAttribute('href').slice(1)]=a;});
  var io=new IntersectionObserver(function(es){es.forEach(function(e){
    if(e.isIntersecting){Object.values(links).forEach(function(a){a.classList.remove('on');});
      var a=links[e.target.id];if(a)a.classList.add('on');}});},{rootMargin:'-45% 0px -50% 0px'});
  Object.keys(links).forEach(function(id){var s=document.getElementById(id);if(s)io.observe(s);});
}
})();
